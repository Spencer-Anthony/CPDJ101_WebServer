package code;

import code.*;
import java.math.BigInteger;

public class Driver{
	
	public static void main(String[] args) {
		
		Encryption comp = new Encryption();
		
		String converting = "abc";
		System.out.println("Original String: " + converting);
		BigInteger a = Convert.toNumber(converting);
		System.out.println("Converted to Number: " + a);
		String string = Convert.fromNumber(a);
		System.out.println("Back to String: " + string + "\n");
		
		BigInteger pub = comp.getKey(1);
		BigInteger n = comp.getKey(2);
		Encryption encrypt = new Encryption(pub, n);
		BigInteger key = encrypt.getKey(3);
		comp.receiveKey(encrypt.getKey(0));
		System.out.println("Public Keys:\n" + pub + "\n" + n);
		System.out.println("Symetric Key:\n" + key + "\n");
		
		converting = "Hello World!";
		System.out.println("Original String: " + converting);
		a = encrypt.encrypt(converting);
		System.out.println("Encrypted Number: " + a);
		String decrypted = comp.decrypt(a);
		System.out.println("Decrypted: " + decrypted);
	}
	
}