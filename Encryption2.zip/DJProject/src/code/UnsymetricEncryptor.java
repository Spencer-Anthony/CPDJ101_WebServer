package code;

import java.math.BigInteger;

public class UnsymetricEncryptor {
	
	BigInteger n;
	BigInteger e;
	
	public UnsymetricEncryptor(BigInteger n, BigInteger e) {
		this.n = n;
		this.e = e;
	}
	
	public BigInteger[] encrypt(int[] arr) {
		BigInteger[] arrOut = new BigInteger[arr.length];
		BigInteger num;
		for (int i = 0; i < arr.length; i++) {
			num = BigInteger.valueOf(arr[i]);
			arrOut[i] = num.modPow(e, n);
		}
		return arrOut;
	}
	
}