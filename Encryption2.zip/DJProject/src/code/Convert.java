package code;

import java.math.BigInteger;

public class Convert {
	
	public static BigInteger toNumber(String string) {
		String num = "";
		String cha;
		//int[] arr = new int[string.length()];
		for (int i = 0; i < string.length(); i++) {
			int a = (int)string.charAt(i);
			cha = "" + a;
			if (cha.length() == 1) num += "00" + cha;
			else if (cha.length() == 2) num += "0" + cha;
			else if (cha.length() == 3) num += cha;
			else throw new IllegalArgumentException("Character not Allowed");
		}
		return new BigInteger(num);
	}
	
	public static String fromNumber(BigInteger big) {
		String stringOut = "";
		String num = big.toString();
		if (num.length() % 3 == 1) num = "00" + num;
		else if (num.length() % 3 == 2) num = "0" + num;
		String cha;
		for (int  i = 0; i < num.length() / 3; i++) {
			cha = "" + num.charAt(i * 3) + num.charAt(i * 3 + 1) + num.charAt(i * 3 + 2);
			int a = Integer.parseInt(cha);
			stringOut += (char)a;
		}
		return stringOut;
	}
}