package code;

import java.math.BigInteger;
import java.util.*;
import java.security.*;

public class Encryption {
	
	BigInteger key, pub, n, priv, sentKey;
	
	public Encryption() {
		//randomly select privKey1 & privKey2, improve this randomness
		SecureRandom rand = new SecureRandom();
		BigInteger prime1 = new BigInteger(257, 50, rand);
		BigInteger prime2 = new BigInteger(257, 50, rand);
		while (prime1 == prime2) prime2 = new BigInteger(6, 50, rand);
		BigInteger num = prime1.subtract(BigInteger.ONE).multiply(prime2.subtract(BigInteger.ONE));
		this.n = prime1.multiply(prime2);
		BigInteger pubKey = new BigInteger(50, 50, rand);
		while (pubKey.compareTo(num) >= 0 || !pubKey.gcd(num).equals(BigInteger.ONE)) {
			pubKey = new BigInteger(50, 50, rand);
		}
		BigInteger privKey = pubKey.modInverse(num);
		//code to send pubKey1 and pubKey2 to server which will use them in the other constructor
		this.pub = pubKey;
		this.priv = privKey;
		
		//code to receive encrypted key from server
		
		//this.key = key.modPow(privKey1, num);
	}
	
	//encryption constructor for the server, it is sent pub keys from computer using first constructor
	public Encryption(BigInteger pubKey, BigInteger n) {
	
		SecureRandom rand = new SecureRandom();
		BigInteger key = new BigInteger(256, rand);
		this.key = key;
		
		this.sentKey = key.modPow(pubKey, n);
		
		
		//send key to computer
	}
	
	
	public BigInteger encrypt(String string) {
		byte[] text = Convert.toNumber(string).toByteArray();
		int[] s = new int[256];
		int[] t = new int[256];
		byte[] k = key.toByteArray();
		for (int i = 0; i < 256; i++) {
			s[i] = i;
			t[i] = k[i % k.length] + 128;
		}
		int j = 0;
		for (int i = 0; i < 256; i++) {
			j = (j + s[i] + t[i]) % 256;
			int temp = s[i];
			s[i] = s[j];
			s[j] = temp;
		}
		int x = 0;
		int y = 0;
		for (int i = 0; i < text.length; i++) {
			x = (x + 1) % 256;
			y = (y + s[x]) % 256;
			int temp = s[x];
			s[x] = s[y];
			s[y] = temp;
			int z = (s[x] + s[y]) % 256;
			byte a = (byte) s[z];
			text[i] = (byte) (text[i] ^ a);
		}
		return new BigInteger(text);
	}
	
	public String decrypt(BigInteger b) {
		byte[] text = b.toByteArray();
		int[] s = new int[256];
		int[] t = new int[256];
		byte[] k = key.toByteArray();
		for (int i = 0; i < 256; i++) {
			s[i] = i;
			t[i] = k[i % k.length] + 128;
		}
		int j = 0;
		for (int i = 0; i < 256; i++) {
			j = (j + s[i] + t[i]) % 256;
			int temp = s[i];
			s[i] = s[j];
			s[j] = temp;
		}
		int x = 0;
		int y = 0;
		for (int i = 0; i < text.length; i++) {
			x = (x + 1) % 256;
			y = (y + s[x]) % 256;
			int temp = s[x];
			s[x] = s[y];
			s[y] = temp;
			int z = (s[x] + s[y]) % 256;
			byte a = (byte) s[z];
			text[i] = (byte) (text[i] ^ a);
		}
		return Convert.fromNumber(new BigInteger(text));
	}
	
	public BigInteger getKey(int i) {
		if (i == 0) return sentKey;
		if (i == 1) return pub;
		if (i == 2) return n;
		return key;
	}
	
	public void receiveKey(BigInteger sentKey) {
		key = sentKey.modPow(priv, n);
	}
}