package code;

import java.math.BigInteger;

public class Driver {

	public static void main(String[] args) {
		Encryption client = new Encryption();
		Encryption server = new Encryption(client.getPublicModulus(), client.getPublicExponent());

		client.acceptEncryptedSessionKey(server.getEncryptedSessionKey());

		String message = "Hello World";
		BigInteger encrypted = client.encrypt(message);
		String decryptedByClient = client.decrypt(encrypted);
		String decryptedByServer = server.decrypt(encrypted);

		System.out.println("Original: " + message);
		System.out.println("Encrypted: " + encrypted);
		System.out.println("Client decrypted: " + decryptedByClient);
		System.out.println("Server decrypted: " + decryptedByServer);

		String secondMessage = "IT WORKS!!!!!";
		System.out.println("Round trip: " + client.decrypt(client.encrypt(secondMessage)));
	}
}
