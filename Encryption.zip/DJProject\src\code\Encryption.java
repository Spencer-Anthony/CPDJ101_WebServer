package code;

import java.math.BigInteger;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.Arrays;

public class Encryption {

	private static final int RSA_BITS = 512;
	private static final BigInteger DEFAULT_PUBLIC_EXPONENT = BigInteger.valueOf(65537L);
	private static final int SESSION_KEY_BITS = 256;

	private final BigInteger modulus;
	private final BigInteger publicExponent;
	private final BigInteger privateExponent;
	private BigInteger key;
	private BigInteger encryptedSessionKey;

	private static final class KeyPair {
		private final BigInteger modulus;
		private final BigInteger publicExponent;
		private final BigInteger privateExponent;

		private KeyPair(BigInteger modulus, BigInteger publicExponent, BigInteger privateExponent) {
			this.modulus = modulus;
			this.publicExponent = publicExponent;
			this.privateExponent = privateExponent;
		}
	}

	public Encryption() {
		this(generateKeyPair(), generateSessionKey(), null);
	}

	// encryption constructor for the server, it is sent pub keys from computer using first constructor
	public Encryption(BigInteger pubKey1, BigInteger pubKey2) {
		this(pubKey1, pubKey2, null, generateSessionKey(), null);
		this.encryptedSessionKey = this.key.modPow(pubKey2, pubKey1);
	}

	private Encryption(KeyPair pair, BigInteger sessionKey, BigInteger encryptedSessionKey) {
		this(pair.modulus, pair.publicExponent, pair.privateExponent, sessionKey, encryptedSessionKey);
	}

	private Encryption(BigInteger modulus, BigInteger publicExponent, BigInteger privateExponent, BigInteger sessionKey,
			BigInteger encryptedSessionKey) {
		this.modulus = modulus;
		this.publicExponent = publicExponent;
		this.privateExponent = privateExponent;
		this.key = sessionKey;
		this.encryptedSessionKey = encryptedSessionKey;
	}

	private static KeyPair generateKeyPair() {
		SecureRandom rand = new SecureRandom();
		BigInteger prime1 = BigInteger.probablePrime(RSA_BITS / 2, rand);
		BigInteger prime2 = BigInteger.probablePrime(RSA_BITS / 2, rand);
		while (prime1.equals(prime2)) {
			prime2 = BigInteger.probablePrime(RSA_BITS / 2, rand);
		}
		BigInteger modulus = prime1.multiply(prime2);
		BigInteger phi = prime1.subtract(BigInteger.ONE).multiply(prime2.subtract(BigInteger.ONE));
		BigInteger publicExponent = DEFAULT_PUBLIC_EXPONENT;
		while (!publicExponent.gcd(phi).equals(BigInteger.ONE)) {
			publicExponent = publicExponent.add(BigInteger.TWO);
		}
		BigInteger privateExponent = publicExponent.modInverse(phi);
		return new KeyPair(modulus, publicExponent, privateExponent);
	}

	private static BigInteger generateSessionKey() {
		SecureRandom rand = new SecureRandom();
		BigInteger sessionKey = BigInteger.ZERO;
		while (sessionKey.signum() == 0) {
			sessionKey = new BigInteger(SESSION_KEY_BITS, rand);
		}
		return sessionKey;
	}

	public BigInteger getPublicModulus() {
		return modulus;
	}

	public BigInteger getPublicExponent() {
		return publicExponent;
	}

	public BigInteger getEncryptedSessionKey() {
		if (encryptedSessionKey == null) {
			throw new IllegalStateException("No encrypted session key is available for this instance.");
		}
		return encryptedSessionKey;
	}

	public BigInteger getSessionKey() {
		return key;
	}

	public void acceptEncryptedSessionKey(BigInteger encryptedKey) {
		if (privateExponent == null || modulus == null) {
			throw new IllegalStateException("This instance does not have the private key needed to decrypt the session key.");
		}
		this.key = encryptedKey.modPow(privateExponent, modulus);
		this.encryptedSessionKey = encryptedKey;
	}

	public BigInteger encrypt(String string) {
		ensureSessionKey();
		byte[] text = string.getBytes(StandardCharsets.UTF_8);
		byte[] cipher = applyStreamCipher(text, key.toByteArray());
		return pack(cipher);
	}

	public String decrypt(BigInteger b) {
		ensureSessionKey();
		byte[] cipher = unpack(b);
		byte[] plain = applyStreamCipher(cipher, key.toByteArray());
		return new String(plain, StandardCharsets.UTF_8);
	}

	private void ensureSessionKey() {
		if (key == null) {
			throw new IllegalStateException("A session key must be established before encrypting or decrypting messages.");
		}
	}

	private static byte[] applyStreamCipher(byte[] text, byte[] keyBytes) {
		int[] s = new int[256];
		int[] t = new int[256];
		for (int i = 0; i < 256; i++) {
			s[i] = i;
			t[i] = Byte.toUnsignedInt(keyBytes[i % keyBytes.length]);
		}
		int j = 0;
		for (int i = 0; i < 256; i++) {
			j = (j + s[i] + t[i]) % 256;
			int temp = s[i];
			s[i] = s[j];
			s[j] = temp;
		}
		int x = 0;
		int y = 0;
		byte[] output = Arrays.copyOf(text, text.length);
		for (int i = 0; i < output.length; i++) {
			x = (x + 1) % 256;
			y = (y + s[x]) % 256;
			int temp = s[x];
			s[x] = s[y];
			s[y] = temp;
			int z = (s[x] + s[y]) % 256;
			output[i] = (byte) (output[i] ^ (byte) s[z]);
		}
		return output;
	}

	private static BigInteger pack(byte[] payload) {
		ByteBuffer buffer = ByteBuffer.allocate(1 + Integer.BYTES + payload.length);
		buffer.put((byte) 1);
		buffer.putInt(payload.length);
		buffer.put(payload);
		return new BigInteger(1, buffer.array());
	}

	private static byte[] unpack(BigInteger value) {
		byte[] bytes = value.toByteArray();
		if (bytes.length > 1 && bytes[0] == 0) {
			bytes = Arrays.copyOfRange(bytes, 1, bytes.length);
		}
		if (bytes.length < Integer.BYTES) {
			throw new IllegalArgumentException("Ciphertext is too short to contain a valid payload length.");
		}
		ByteBuffer buffer = ByteBuffer.wrap(bytes);
		byte sentinel = buffer.get();
		if (sentinel != 1) {
			throw new IllegalArgumentException("Ciphertext payload is missing its sentinel byte.");
		}
		int length = buffer.getInt();
		if (length < 0 || length > buffer.remaining()) {
			throw new IllegalArgumentException("Ciphertext payload length is invalid.");
		}
		byte[] payload = new byte[length];
		buffer.get(payload);
		return payload;
	}
}
