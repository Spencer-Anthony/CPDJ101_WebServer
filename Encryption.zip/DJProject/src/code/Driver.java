package code;

import code.*;
import java.math.BigInteger;

public class Driver{
	
	public static void main(String[] args) {
		
		Encryption comp = new Encryption();
		
		BigInteger a = Convert.toNumber("abc");
		System.out.println(a);
		String string = Convert.fromNumber(a);
		System.out.println(string);
		
		BigInteger x = BigInteger.TEN;
		Encryption encrypt = new Encryption(x, x);
		System.out.println(encrypt.decrypt(encrypt.encrypt(string)));
		
		
		System.out.println(encrypt.decrypt(encrypt.encrypt("Hello World")));
		System.out.println(encrypt.decrypt(encrypt.encrypt("IT WORKS!!!!!")));
		
	}
	
}