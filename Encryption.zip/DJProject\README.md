# DJProject Encryption Demo

This project demonstrates a simple hybrid encryption flow:

- `Encryption()` creates a client instance with an RSA-style key pair.
- `new Encryption(modulus, exponent)` creates the server side and generates a session key encrypted for the client.
- `acceptEncryptedSessionKey(...)` finalizes the shared session key on the client.
- `encrypt(...)` and `decrypt(...)` use the shared session key.

## Build

From the project root:

```powershell
javac -d bin src\module-info.java src\code\*.java
```

## Run

```powershell
java -p bin -m DJProject/code.Driver
```

The driver prints a successful round trip for a sample message.
